import React, { useEffect } from 'react'
import PopupModal from './PopupModel'

function AboutContent() {
  return (
    <>
    <div>
      <h3 style={{ color: "#004AAD" }}>About Us</h3>
                <h2>Jay Sanghvi & Associates</h2>
                <p>
                  We are trusted professionals with high degree of ethics
                  providing services in the field of tax and audit and other
                  statutory requirements applicable to the business segment of
                  the society. Our mission is to diversify from traditional
                  practice of tax and audit regulatory requirements to
                  comprehensive and active support to the business enterprises
                  by providing wide range of advisory functions, management
                  support services to strengthen and optimize productivity and
                  profitability in the clients business with full compliance of
                  business laws and regulatory frame work.

                  The success of our profession as a CA consultant in Ahmedabad is due to our clients and the confidence & trust they have placed on us. We believe in supplying timely service to our clients. We are the best chartered accountant in Ahmedabad and our relation with our clients is based on ethical values, professional excellence and confidentiality.
                </p>
                
    </div>
    </>
  )
}

export default AboutContent
